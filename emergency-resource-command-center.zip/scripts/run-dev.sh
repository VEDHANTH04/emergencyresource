#!/bin/sh
(cd backend && python run.py) & (cd frontend && npm run dev)

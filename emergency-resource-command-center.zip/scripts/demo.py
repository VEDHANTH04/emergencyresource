import requests,time
B='http://localhost:5000/api'
for _ in range(8):
 x=requests.post(B+'/match/run',json={'weights':{'urgency':.35,'distance':.25,'suitability':.25,'availability':.15}}).json();print(x)
 if x.get('done'):break
 time.sleep(.3)
print(requests.get(B+'/analytics').json())

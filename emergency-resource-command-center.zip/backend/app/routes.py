from flask import Blueprint,request,jsonify
from .db import rows,conn
from .services.engine import Engine
api=Blueprint("api",__name__);eng=Engine()
@api.get("/emergencies")
def emergencies():return jsonify(rows("select * from emergency_requests order by severity desc,created_at"))
@api.post("/emergencies")
def add_e():
 d=request.json or {};req=["title","severity","lat","lon","required_type"]
 if any(k not in d for k in req):return jsonify(error="missing required field"),400
 with conn() as c:
  with c.cursor() as cur:
   cur.execute("insert into emergency_requests(title,severity,lat,lon,required_type,required_equipment,required_capacity) values(%s,%s,%s,%s,%s,%s,%s) returning *",(d["title"],d["severity"],d["lat"],d["lon"],d["required_type"],d.get("required_equipment",[]),d.get("required_capacity",1)))
   row=cur.fetchone();cols=[x.name for x in cur.description]
 return jsonify(dict(zip(cols,row))),201
@api.get("/resources")
def resources():return jsonify(rows("select * from resources order by available desc,id"))
@api.post("/resources")
def add_r():
 d=request.json or {}
 with conn() as c:
  with c.cursor() as cur:
   cur.execute("insert into resources(name,resource_type,lat,lon,equipment,capacity,eta_minutes,available) values(%s,%s,%s,%s,%s,%s,%s,%s) returning *",(d["name"],d["resource_type"],d["lat"],d["lon"],d.get("equipment",[]),d.get("capacity",1),d.get("eta_minutes",30),d.get("available",True)))
   row=cur.fetchone();cols=[x.name for x in cur.description]
 return jsonify(dict(zip(cols,row))),201
@api.post("/match/run")
def run():return jsonify(eng.run((request.json or {}).get("weights")))
@api.get("/match/status")
def status():return jsonify({"last":eng.last})
@api.post("/simulation/start")
def sim():return jsonify(eng.simulate(int((request.json or {}).get("count",5))))
@api.get("/simulation")
def sim_events():return jsonify(rows("select * from simulation_events order by created_at desc limit 50"))
@api.get("/analytics")
def analytics():return jsonify(eng.analytics())

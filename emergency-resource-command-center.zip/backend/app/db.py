import os,psycopg
def conn(): return psycopg.connect(os.getenv("DATABASE_URL","postgresql://postgres:postgres@localhost:5432/emergency_center"))
def rows(sql,p=()):
 with conn() as c:
  with c.cursor() as cur:
   cur.execute(sql,p)
   return [dict(zip([x.name for x in cur.description],r)) for r in cur.fetchall()] if cur.description else []

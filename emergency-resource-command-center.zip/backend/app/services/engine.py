from ..db import rows,conn
from ..algorithms.priority_queue import MaxHeap
from ..algorithms.matching import candidates
from ..algorithms.greedy import choose,DEFAULT
import random,time
class Engine:
 def __init__(self):self.last=None
 def run(self,weights=None):
  w={**DEFAULT,**(weights or {})}
  es=rows("select * from emergency_requests where status='pending'")
  q=MaxHeap(es,key=lambda e:e["severity"]*1000000-e["created_at"].timestamp())
  e=q.pop()
  if not e:return {"done":True,"message":"No pending emergencies","queue":[]}
  rs=rows("select * from resources where available=true");cs=candidates(e,rs);best,ranked=choose(e,cs,w)
  if best:
   with conn() as c:
    with c.cursor() as cur:
     cur.execute("update resources set available=false where id=%s",(best["resource"]["id"],))
     cur.execute("update emergency_requests set status='matched' where id=%s",(e["id"],))
     cur.execute("insert into assignments(emergency_id,resource_id,distance_km,score,rationale) values(%s,%s,%s,%s,%s)",(e["id"],best["resource"]["id"],best["distance_km"],best["score"],f'Chosen {best["resource"]["name"]}: highest feasible local score {best["score"]}.'))
  else:
   with conn() as c:c.execute("update emergency_requests set status='unmatched' where id=%s",(e["id"],))
  self.last={"emergency":e,"candidates":ranked,"selected":best}
  return {"done":False,"trace":self.last,"queue":rows("select id,title,severity,status from emergency_requests where status='pending' order by severity desc")}
 def analytics(self):
  q=lambda s:rows(s)[0]["n"]
  return {"total_requests":q("select count(*) n from emergency_requests"),"matched":q("select count(*) n from emergency_requests where status='matched'"),"unmatched":q("select count(*) n from emergency_requests where status='unmatched'"),"avg_distance_km":q("select coalesce(avg(distance_km),0) n from assignments"),"resource_utilization_pct":q("select coalesce(100*sum((not available)::int)/nullif(count(*),0),0) n from resources")}
 def simulate(self,n):
  types=["ambulance","fire","rescue","police"]
  with conn() as c:
   with c.cursor() as cur:
    for i in range(n):
     sev=random.randint(2,5);typ=random.choice(types);lat=17.40+random.uniform(-.1,.1);lon=78.47+random.uniform(-.1,.1)
     cur.execute("insert into emergency_requests(title,severity,lat,lon,required_type,required_equipment) values(%s,%s,%s,%s,%s,%s)",(f"SIM-{int(time.time())}-{i}",sev,lat,lon,typ,[]))
     cur.execute("insert into simulation_events(event_type,payload) values('emergency_created',%s)",({"severity":sev,"type":typ},))
  return {"created":n}

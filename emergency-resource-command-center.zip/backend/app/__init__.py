from flask import Flask
from flask_cors import CORS
from .routes import api

def create_app():
 a=Flask(__name__); CORS(a); a.register_blueprint(api,url_prefix='/api'); return a

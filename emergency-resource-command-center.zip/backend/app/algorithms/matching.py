from math import radians,sin,cos,asin,sqrt
def haversine(a,b,c,d):
 R=6371;p1,p2=radians(a),radians(c);dp=radians(c-a);dl=radians(d-b)
 x=sin(dp/2)**2+cos(p1)*cos(p2)*sin(dl/2)**2
 return 2*R*asin(sqrt(x))
def suitability(e,r):
 ok=e["required_type"]==r["resource_type"] and set(e.get("required_equipment") or [])<=set(r.get("equipment") or []) and r["capacity"]>=e.get("required_capacity",1)
 s=(50 if e["required_type"]==r["resource_type"] else 0)+(30 if set(e.get("required_equipment") or [])<=set(r.get("equipment") or []) else 0)+(20 if r["capacity"]>=e.get("required_capacity",1) else 0)
 return s,ok
def candidates(e,rs,radius=150):
 out=[]
 for r in rs:
  if not r["available"]:continue
  d=haversine(e["lat"],e["lon"],r["lat"],r["lon"]);s,ok=suitability(e,r)
  if ok and d<=radius:out.append({"resource":r,"distance_km":round(d,2),"suitability":s})
 return out

DEFAULT={"urgency":.35,"distance":.25,"suitability":.25,"availability":.15}
def score(e,c,w=DEFAULT):
 d=c["distance_km"];r=c["resource"]
 parts={"urgency":min(100,e["severity"]*20)*w["urgency"],"distance":max(0,100-d/150*100)*w["distance"],"suitability":c["suitability"]*w["suitability"],"availability":(100 if r["available"] else 0)*w["availability"]}
 return round(sum(parts.values()),2),{k:round(v,2) for k,v in parts.items()}
def choose(e,cs,w=DEFAULT):
 x=[]
 for c in cs:
  s,b=score(e,c,w);x.append({**c,"score":s,"breakdown":b})
 return (max(x,key=lambda z:z["score"]) if x else None),sorted(x,key=lambda z:z["score"],reverse=True)

class MaxHeap:
 def __init__(self,items=(),key=lambda x:x):
  self.a=[]; self.key=key
  for x in items:self.push(x)
 def push(self,x):
  self.a.append(x); i=len(self.a)-1
  while i:
   p=(i-1)//2
   if self.key(self.a[p])>=self.key(self.a[i]):break
   self.a[p],self.a[i]=self.a[i],self.a[p]; i=p
 def pop(self):
  if not self.a:return None
  x=self.a[0]; y=self.a.pop()
  if self.a:
   self.a[0]=y;i=0
   while 1:
    l,r=2*i+1,2*i+2;b=i
    if l<len(self.a) and self.key(self.a[l])>self.key(self.a[b]):b=l
    if r<len(self.a) and self.key(self.a[r])>self.key(self.a[b]):b=r
    if b==i:break
    self.a[i],self.a[b]=self.a[b],self.a[i];i=b
  return x
 def peek(self):return self.a[0] if self.a else None
 def __len__(self):return len(self.a)

truncate assignments,emergency_requests,resources,resource_types,locations,algorithm_runs,simulation_events restart identity cascade;
insert into resource_types(name) values('ambulance'),('fire'),('rescue'),('police');
insert into locations(name,lat,lon) values('Central',17.385,78.4867),('Secunderabad',17.4399,78.4983),('Gachibowli',17.4401,78.3489);
insert into resources(name,resource_type,lat,lon,equipment,capacity,eta_minutes,available) values
('AMB-01','ambulance',17.385,78.4867,array['oxygen','trauma'],2,8,true),
('AMB-02','ambulance',17.440,78.350,array['oxygen'],1,18,true),
('FIRE-01','fire',17.420,78.450,array['hose','ladder'],4,12,true),
('RES-01','rescue',17.370,78.500,array['rope','extrication'],5,15,true),
('POL-01','police',17.460,78.490,array['barrier'],4,10,true);
insert into emergency_requests(title,severity,lat,lon,required_type,required_equipment,required_capacity) values
('Road collision',5,17.390,78.480,'ambulance',array['oxygen'],1),
('Building fire',5,17.410,78.470,'fire',array['hose'],2),
('Flood rescue',4,17.380,78.510,'rescue',array['rope'],3),
('Crowd control',2,17.450,78.490,'police',array['barrier'],2),
('Medical support',3,17.400,78.460,'ambulance',array['trauma'],1);

import requests
def test_api(): assert requests.get('http://localhost:5000/api/emergencies',timeout=2).status_code==200

from app.algorithms.priority_queue import MaxHeap
from app.algorithms.matching import candidates
from app.algorithms.greedy import choose
def test_heap():
 q=MaxHeap([{"p":2},{"p":5},{"p":3}],lambda x:x["p"]);assert q.pop()["p"]==5
def test_candidates():
 e={"lat":0,"lon":0,"required_type":"ambulance","required_equipment":["oxygen"],"required_capacity":1}
 r={"id":1,"resource_type":"ambulance","lat":.01,"lon":0,"equipment":["oxygen"],"capacity":2,"available":True}
 assert len(candidates(e,[r]))==1
def test_score():
 b,_=choose({"severity":5},[{"distance_km":5,"suitability":100,"resource":{"available":True}}]);assert b["score"]>0

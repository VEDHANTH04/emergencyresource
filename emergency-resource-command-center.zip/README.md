# Emergency Resource Command Center
Problem 90 — Emergency Resource Matching. Compact full-stack demo.

## Run
1. `docker compose up -d db`
2. `psql -U postgres -h localhost -d emergency_center -f backend/db/schema.sql && psql -U postgres -h localhost -d emergency_center -f backend/db/seed.sql`
3. `cd backend && python -m venv .venv && .venv\Scripts\activate` (Windows) or `source .venv/bin/activate`
4. `pip install -r requirements.txt && python run.py`
5. In another terminal: `cd frontend && npm install && npm run dev`

Open the Vite URL, normally `http://localhost:5173`.
Default DB URL: `postgresql://postgres:postgres@localhost:5432/emergency_center`.

## Demo controls
NEXT STEP = pop highest-priority emergency and perform one greedy assignment.
AUTO RUN = repeatedly execute steps.
SIMULATE = create five new emergencies.
Weights are editable in the footer.

## Troubleshooting
Check PostgreSQL is running and `DATABASE_URL` if the API cannot connect. Map tiles need internet.
